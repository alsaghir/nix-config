See VEM_PS2_Gui.png for file structure/GUI description.

See File format.png for how to save .client files as UTF-8

sample.client contains documentation on how to create a client file

schema.client shows all available fields available for client files